import { 
  analysisRequests, 
  type AnalysisRequest, 
  type InsertAnalysisRequest 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createAnalysisRequest(request: InsertAnalysisRequest): Promise<AnalysisRequest>;
  getAnalysisRequests(): Promise<AnalysisRequest[]>;
  getAnalysisRequest(id: number): Promise<AnalysisRequest | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createAnalysisRequest(request: InsertAnalysisRequest): Promise<AnalysisRequest> {
    const [newItem] = await db.insert(analysisRequests).values(request).returning();
    return newItem;
  }

  async getAnalysisRequests(): Promise<AnalysisRequest[]> {
    return await db.select().from(analysisRequests).orderBy(desc(analysisRequests.createdAt));
  }

  async getAnalysisRequest(id: number): Promise<AnalysisRequest | undefined> {
    const [item] = await db.select().from(analysisRequests).where(eq(analysisRequests.id, id));
    return item;
  }
}

export const storage = new DatabaseStorage();
