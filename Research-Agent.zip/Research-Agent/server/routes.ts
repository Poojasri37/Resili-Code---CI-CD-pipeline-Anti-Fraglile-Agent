import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini Client
const genAI = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY || "dummy",
  httpOptions: {
    baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
    apiVersion: "",
  },
});

const model = "gemini-2.5-flash"; // Use Flash for speed in TRL-6 prototype

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // --- 1. DOM Analysis ---
  app.post(api.analysis.dom.path, async (req, res) => {
    try {
      const input = api.analysis.dom.input.parse(req.body);
      
      const prompt = `
        You are Resili-Code, a TRL-6 autonomous agent.
        Analyze the following two DOM snippets (Old vs New).
        Infer the user intent and what likely changed/broke.
        Construct a robust CSS selector that works for the NEW DOM but preserves the intent of the old element.
        
        OLD DOM:
        ${input.oldDom}
        
        NEW DOM:
        ${input.newDom}
        
        Return JSON ONLY:
        {
          "selector": "string",
          "explanation": "string",
          "confidence": number (0-1),
          "reasoning": ["step 1", "step 2"]
        }
      `;

      const result = await genAI.models.generateContent({
        model,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      });
      
      const responseText = result.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
      const jsonResponse = JSON.parse(responseText.replace(/```json|```/g, "")); // Basic cleanup

      // Log to DB
      await storage.createAnalysisRequest({
        type: 'dom',
        inputContent: input,
        outputContent: jsonResponse
      });

      res.json(jsonResponse);
    } catch (error) {
      console.error("DOM Analysis Error:", error);
      res.status(500).json({ message: "Failed to analyze DOM" });
    }
  });

  // --- 2. Code Analysis ---
  app.post(api.analysis.code.path, async (req, res) => {
    try {
      const input = api.analysis.code.input.parse(req.body);

      const prompt = `
        You are Resili-Code, an expert software engineer.
        Analyze the following code for bugs, logic errors, and best practices.
        Fix the code while preserving the original intent.
        
        CODE:
        ${input.code}
        
        Return JSON ONLY:
        {
          "originalCode": "string (the input code)",
          "fixedCode": "string (the fixed code)",
          "explanation": "string",
          "changes": [
            { "line": number, "content": "string", "type": "add" | "remove" | "modify" }
          ]
        }
      `;

      const result = await genAI.models.generateContent({
        model,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      });

      const responseText = result.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
      const jsonResponse = JSON.parse(responseText.replace(/```json|```/g, ""));

      await storage.createAnalysisRequest({
        type: 'code',
        inputContent: input,
        outputContent: jsonResponse
      });

      res.json(jsonResponse);
    } catch (error) {
      console.error("Code Analysis Error:", error);
      res.status(500).json({ message: "Failed to analyze code" });
    }
  });

  // --- 3. Log Analysis ---
  app.post(api.analysis.log.path, async (req, res) => {
    try {
      const input = api.analysis.log.input.parse(req.body);

      const prompt = `
        You are Resili-Code. Analyze the following system logs/error stack trace.
        Identify the root cause and propose a fix.
        Determine if "Auto Heal" is possible (meaning a safe, deterministic code change can fix it).
        
        LOGS:
        ${input.logs}
        
        CONTEXT:
        ${input.context || "No additional context."}
        
        Return JSON ONLY:
        {
          "rootCause": "string",
          "fixProposal": "string (code snippet or command)",
          "canAutoHeal": boolean,
          "explanation": "string"
        }
      `;

      const result = await genAI.models.generateContent({
        model,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      });

      const responseText = result.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
      const jsonResponse = JSON.parse(responseText.replace(/```json|```/g, ""));

      await storage.createAnalysisRequest({
        type: 'log',
        inputContent: input,
        outputContent: jsonResponse
      });

      res.json(jsonResponse);
    } catch (error) {
      console.error("Log Analysis Error:", error);
      res.status(500).json({ message: "Failed to analyze logs" });
    }
  });

  // --- 4. RAG Analysis (Simulated) ---
  app.post(api.analysis.rag.path, async (req, res) => {
    try {
      const input = api.analysis.rag.input.parse(req.body);

      // In a real TRL-7 system, we would embed 'input.fileContent' and search vector DB.
      // For TRL-6 prototype with Gemini 1.5/2.0 context window, we can inject the file content directly.
      const prompt = `
        You are Resili-Code (RAG Mode). 
        Answer the user query based ONLY on the provided file content.
        
        FILE CONTENT:
        ${input.fileContent || "No file provided."}
        
        USER QUERY:
        ${input.query}
        
        Return JSON ONLY:
        {
          "answer": "string",
          "context": ["string (relevant snippets from file)"]
        }
      `;

      const result = await genAI.models.generateContent({
        model,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      });

      const responseText = result.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
      const jsonResponse = JSON.parse(responseText.replace(/```json|```/g, ""));

      await storage.createAnalysisRequest({
        type: 'rag',
        inputContent: input,
        outputContent: jsonResponse
      });

      res.json(jsonResponse);
    } catch (error) {
      console.error("RAG Analysis Error:", error);
      res.status(500).json({ message: "Failed to perform RAG analysis" });
    }
  });

  // --- History ---
  app.get(api.analysis.history.path, async (req, res) => {
    const history = await storage.getAnalysisRequests();
    res.json(history);
  });

  return httpServer;
}
