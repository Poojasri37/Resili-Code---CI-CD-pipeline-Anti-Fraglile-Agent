export { registerImageRoutes } from "./routes";
export { ai, generateImage } from "./client";

