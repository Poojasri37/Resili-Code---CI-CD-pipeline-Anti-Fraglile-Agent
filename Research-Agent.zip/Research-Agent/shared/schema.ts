import { pgTable, text, serial, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Reuse the chat models from the integration blueprint if needed,
// but for the specific "Analysis" workflow, we might want dedicated tables.

export const analysisRequests = pgTable("analysis_requests", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'dom', 'code', 'log', 'rag'
  inputContent: jsonb("input_content").notNull(), // Stores the raw input (DOMs, code, logs)
  outputContent: jsonb("output_content"), // Stores the agent's response
  isFavorite: boolean("is_favorite").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnalysisRequestSchema = createInsertSchema(analysisRequests).omit({
  id: true,
  createdAt: true,
});

export type AnalysisRequest = typeof analysisRequests.$inferSelect;
export type InsertAnalysisRequest = z.infer<typeof insertAnalysisRequestSchema>;

// === API Types ===

// DOM Analysis
export const domAnalysisInputSchema = z.object({
  oldDom: z.string(),
  newDom: z.string(),
});
export type DomAnalysisInput = z.infer<typeof domAnalysisInputSchema>;

export interface DomAnalysisResponse {
  selector: string;
  explanation: string;
  confidence: number;
  reasoning: string[]; // Step-by-step reasoning
}

// Code Analysis
export const codeAnalysisInputSchema = z.object({
  code: z.string(),
  filename: z.string().optional(),
});
export type CodeAnalysisInput = z.infer<typeof codeAnalysisInputSchema>;

export interface CodeAnalysisResponse {
  originalCode: string;
  fixedCode: string;
  explanation: string;
  changes: Array<{ line: number; content: string; type: 'add' | 'remove' | 'modify' }>;
}

// Log Analysis
export const logAnalysisInputSchema = z.object({
  logs: z.string(),
  context: z.string().optional(),
});
export type LogAnalysisInput = z.infer<typeof logAnalysisInputSchema>;

export interface LogAnalysisResponse {
  rootCause: string;
  fixProposal: string;
  canAutoHeal: boolean;
  explanation: string;
}

// RAG Analysis
export const ragAnalysisInputSchema = z.object({
  query: z.string(),
  fileContent: z.string().optional(), // For simple text/code upload simulation
});
export type RagAnalysisInput = z.infer<typeof ragAnalysisInputSchema>;

export interface RagAnalysisResponse {
  answer: string;
  context: string[];
}
