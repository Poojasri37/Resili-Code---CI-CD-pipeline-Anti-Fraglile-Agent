import { z } from 'zod';
import { 
  insertAnalysisRequestSchema, 
  analysisRequests,
  domAnalysisInputSchema,
  codeAnalysisInputSchema,
  logAnalysisInputSchema,
  ragAnalysisInputSchema 
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  analysis: {
    dom: {
      method: 'POST' as const,
      path: '/api/analysis/dom',
      input: domAnalysisInputSchema,
      responses: {
        200: z.object({
          selector: z.string(),
          explanation: z.string(),
          confidence: z.number(),
          reasoning: z.array(z.string())
        }),
        500: errorSchemas.internal
      }
    },
    code: {
      method: 'POST' as const,
      path: '/api/analysis/code',
      input: codeAnalysisInputSchema,
      responses: {
        200: z.object({
          originalCode: z.string(),
          fixedCode: z.string(),
          explanation: z.string(),
          changes: z.array(z.object({
            line: z.number(),
            content: z.string(),
            type: z.enum(['add', 'remove', 'modify'])
          }))
        }),
        500: errorSchemas.internal
      }
    },
    log: {
      method: 'POST' as const,
      path: '/api/analysis/log',
      input: logAnalysisInputSchema,
      responses: {
        200: z.object({
          rootCause: z.string(),
          fixProposal: z.string(),
          canAutoHeal: z.boolean(),
          explanation: z.string()
        }),
        500: errorSchemas.internal
      }
    },
    rag: {
      method: 'POST' as const,
      path: '/api/analysis/rag',
      input: ragAnalysisInputSchema,
      responses: {
        200: z.object({
          answer: z.string(),
          context: z.array(z.string())
        }),
        500: errorSchemas.internal
      }
    },
    history: {
      method: 'GET' as const,
      path: '/api/analysis/history',
      responses: {
        200: z.array(z.custom<typeof analysisRequests.$inferSelect>())
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
