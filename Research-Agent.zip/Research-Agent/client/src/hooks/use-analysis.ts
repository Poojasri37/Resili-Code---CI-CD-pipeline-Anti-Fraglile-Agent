import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type DomAnalysisInput, type CodeAnalysisInput, type LogAnalysisInput, type RagAnalysisInput } from "@shared/routes";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Helper to handle AI voice feedback
const speak = (text: string) => {
  const enabled = localStorage.getItem("voice_enabled") === "true";
  if (enabled && window.speechSynthesis) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.1; // Slightly faster for tech content
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  }
};

export function useDomAnalysis() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: DomAnalysisInput) => {
      const res = await apiRequest(api.analysis.dom.method, api.analysis.dom.path, data);
      return api.analysis.dom.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({ title: "DOM Analysis Complete", description: `Confidence: ${Math.round(data.confidence * 100)}%` });
      speak(`Analysis complete. I found a selector with ${Math.round(data.confidence * 100)} percent confidence. ${data.explanation}`);
    },
    onError: (error) => {
      toast({ title: "Analysis Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useCodeAnalysis() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: CodeAnalysisInput) => {
      const res = await apiRequest(api.analysis.code.method, api.analysis.code.path, data);
      return api.analysis.code.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({ title: "Code Analyzed", description: `Found ${data.changes.length} changes.` });
      speak(`I have analyzed the code and found ${data.changes.length} potential improvements. ${data.explanation}`);
    },
    onError: (error) => {
      toast({ title: "Analysis Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useLogAnalysis() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: LogAnalysisInput) => {
      const res = await apiRequest(api.analysis.log.method, api.analysis.log.path, data);
      return api.analysis.log.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      const healMsg = data.canAutoHeal ? "Auto-heal is available." : "Manual intervention required.";
      toast({ title: "Log Analysis Complete", description: "Root cause identified." });
      speak(`Root cause identified. ${data.rootCause}. ${healMsg}`);
    },
    onError: (error) => {
      toast({ title: "Analysis Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useRagAnalysis() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: RagAnalysisInput) => {
      const res = await apiRequest(api.analysis.rag.method, api.analysis.rag.path, data);
      return api.analysis.rag.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      speak(data.answer);
    },
    onError: (error) => {
      toast({ title: "Query Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useAnalysisHistory() {
  return useQuery({
    queryKey: [api.analysis.history.path],
    queryFn: async () => {
      const res = await fetch(api.analysis.history.path);
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.analysis.history.responses[200].parse(await res.json());
    }
  });
}
