import { useState } from "react";
import { useRagAnalysis } from "@/hooks/use-analysis";
import { AnalysisOverlay } from "@/components/ui/AnalysisOverlay";
import { Upload, Search, Database, FileText } from "lucide-react";
import { motion } from "framer-motion";

export default function RagAnalysis() {
  const [query, setQuery] = useState("");
  const [fileContent, setFileContent] = useState("");
  const { mutate, isPending, data } = useRagAnalysis();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ query, fileContent });
  };

  return (
    <div className="h-screen flex flex-col bg-background relative overflow-hidden">
      <AnalysisOverlay isVisible={isPending} message="Retrieving Context & Generating Answers..." />

      {/* Hero Section / Search */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 max-w-4xl mx-auto w-full z-10">
        {!data && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="w-20 h-20 bg-gradient-to-tr from-primary to-accent rounded-2xl mx-auto mb-6 flex items-center justify-center shadow-2xl shadow-primary/30">
              <Database className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-4 tracking-tight">Knowledge Base Query</h1>
            <p className="text-xl text-muted-foreground">
              Ask questions about your codebase, documentation, or upload specific context files.
            </p>
          </motion.div>
        )}

        <form onSubmit={handleSearch} className="w-full relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all opacity-50" />
          <div className="relative bg-card border border-white/10 rounded-2xl p-2 shadow-2xl flex items-center gap-2">
            <div className="pl-4">
              <Search className="w-6 h-6 text-muted-foreground" />
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask a question about the architecture..."
              className="flex-1 bg-transparent border-none text-lg p-4 focus:ring-0 text-white placeholder:text-muted-foreground/50"
            />
            <button
              type="submit"
              disabled={!query || isPending}
              className="px-8 py-3 bg-white text-black font-bold rounded-xl hover:bg-white/90 transition-all disabled:opacity-50"
            >
              Ask
            </button>
          </div>
          
          {/* File Upload Simulation */}
          <div className="mt-4 flex justify-center">
            <button 
              type="button"
              className="text-xs flex items-center gap-2 text-muted-foreground hover:text-white transition-colors"
              onClick={() => {
                const fakeContent = "Architecture Decision Record: We chose React for the frontend due to its component ecosystem.";
                setFileContent(fakeContent);
                alert("Simulated: File context loaded!");
              }}
            >
              <Upload className="w-3 h-3" />
              {fileContent ? "Context Loaded (1 File)" : "Upload Context File (Optional)"}
            </button>
          </div>
        </form>
      </div>

      {/* Results Section - Slides up when data exists */}
      {data && (
        <motion.div 
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border-t border-white/10 flex-1 max-h-[60vh] overflow-y-auto p-8 shadow-[0_-20px_40px_rgba(0,0,0,0.3)] z-20"
        >
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Answer</h3>
              <p className="text-xl text-white leading-relaxed font-light">
                {data.answer}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-8 border-t border-white/5">
              <div className="col-span-full text-sm font-bold text-muted-foreground uppercase tracking-widest mb-2">
                Retrieved Context Sources
              </div>
              {data.context.map((ctx, idx) => (
                <div key={idx} className="bg-secondary/30 p-4 rounded-xl border border-white/5 hover:border-primary/30 transition-colors group cursor-default">
                  <div className="flex items-center gap-2 mb-2 text-primary text-xs font-mono">
                    <FileText className="w-3 h-3" />
                    <span>Source Fragment {idx + 1}</span>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3 group-hover:text-white transition-colors">
                    {ctx}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
