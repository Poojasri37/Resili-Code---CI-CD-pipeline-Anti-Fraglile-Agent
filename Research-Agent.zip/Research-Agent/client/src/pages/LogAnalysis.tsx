import { useState } from "react";
import { useLogAnalysis } from "@/hooks/use-analysis";
import { AnalysisOverlay } from "@/components/ui/AnalysisOverlay";
import { CodeBlock } from "@/components/ui/CodeBlock";
import { FileText, Activity, AlertTriangle, Zap, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function LogAnalysis() {
  const [logs, setLogs] = useState("");
  const { mutate, isPending, data } = useLogAnalysis();
  const { toast } = useToast();
  const [healing, setHealing] = useState(false);

  const handleAnalyze = () => {
    mutate({ logs });
  };

  const handleAutoHeal = () => {
    setHealing(true);
    setTimeout(() => {
      setHealing(false);
      toast({
        title: "System Patched",
        description: "The proposed fix has been successfully applied to the runtime environment.",
        variant: "default",
        className: "bg-green-500 text-white border-none"
      });
    }, 2000);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 pb-20">
      <header>
        <h1 className="text-3xl font-bold text-white mb-2">Log Forensics</h1>
        <p className="text-muted-foreground text-lg">
          Paste stack traces or error logs to identify root causes and generate auto-healing patches.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-8 relative">
        <AnalysisOverlay isVisible={isPending} message="Correlating Events & Tracing Errors..." />

        {/* Input Area */}
        <div className="bg-card border border-white/10 rounded-xl overflow-hidden shadow-xl">
          <div className="bg-secondary/50 px-4 py-3 border-b border-white/5 flex items-center gap-2">
            <FileText className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">Error Log Input</span>
          </div>
          <textarea
            value={logs}
            onChange={(e) => setLogs(e.target.value)}
            className="w-full h-48 bg-[#0d1117] p-4 font-mono text-sm text-red-300 resize-y focus:outline-none border-none placeholder:text-white/10"
            placeholder="ERROR 2024-05-21: NullPointerReference at Service.process (service.ts:42)..."
          />
          <div className="p-4 bg-secondary/20 border-t border-white/5 flex justify-end">
            <button
              onClick={handleAnalyze}
              disabled={isPending || !logs}
              className="px-6 py-2 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <Activity className="w-4 h-4" />
              Analyze Logs
            </button>
          </div>
        </div>

        {/* Results */}
        <AnimatePresence>
          {data && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {/* Root Cause Card */}
              <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4 text-destructive-foreground">
                  <div className="p-2 bg-destructive/20 rounded-lg">
                    <AlertTriangle className="w-6 h-6 text-red-500" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Root Cause Identified</h3>
                </div>
                <p className="text-white/80 leading-relaxed mb-4">
                  {data.rootCause}
                </p>
                <div className="text-sm text-white/50 bg-black/20 p-4 rounded-lg">
                  {data.explanation}
                </div>
              </div>

              {/* Fix Proposal Card */}
              <div className="bg-card border border-white/10 rounded-xl p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-primary/20 rounded-lg">
                    <Zap className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Proposed Resolution</h3>
                </div>
                
                <div className="flex-1 mb-6">
                  <CodeBlock code={data.fixProposal} language="javascript" className="h-full" />
                </div>

                {data.canAutoHeal ? (
                  <button
                    onClick={handleAutoHeal}
                    disabled={healing}
                    className="w-full py-3 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl shadow-lg shadow-green-900/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100"
                  >
                    {healing ? (
                      <span className="animate-pulse">Applying Patch...</span>
                    ) : (
                      <>
                        <ShieldCheck className="w-5 h-5" />
                        Execute Auto-Heal
                      </>
                    )}
                  </button>
                ) : (
                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-yellow-200 text-sm text-center">
                    Manual intervention required for this issue type.
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
