import { useState } from "react";
import { useCodeAnalysis } from "@/hooks/use-analysis";
import { CodeBlock } from "@/components/ui/CodeBlock";
import { AnalysisOverlay } from "@/components/ui/AnalysisOverlay";
import { Sparkles, ArrowRight, FileCode } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export default function CodeEditor() {
  const [code, setCode] = useState(`function calculateTotal(items) {
  let total = 0;
  for (let i = 0; i < items.length; i++) {
    total += items[i].price;
  }
  return total;
}`);
  const { mutate, isPending, data } = useCodeAnalysis();

  const handleAnalyze = () => {
    mutate({ code, filename: "script.js" });
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      <div className="px-8 py-6 border-b border-white/5 flex items-center justify-between bg-card/50 backdrop-blur-sm z-10">
        <div>
          <h1 className="text-2xl font-bold font-display text-white">Intelligent Editor</h1>
          <p className="text-sm text-muted-foreground">Self-healing code environment</p>
        </div>
        <button
          onClick={handleAnalyze}
          disabled={isPending || !code}
          className="px-6 py-2.5 bg-accent hover:bg-accent/90 text-white font-medium rounded-lg shadow-lg shadow-accent/20 flex items-center gap-2 transition-all disabled:opacity-50"
        >
          {isPending ? (
            <span className="animate-spin mr-1">⚡</span>
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          {isPending ? "Reasoning..." : "Analyze & Fix"}
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden relative">
        <AnalysisOverlay isVisible={isPending} message="Parsing AST & Generating Fixes..." />
        
        {/* Editor Pane */}
        <div className="flex-1 border-r border-white/5 flex flex-col bg-[#0d1117]">
          <div className="px-4 py-2 bg-secondary/30 border-b border-white/5 flex items-center gap-2">
            <FileCode className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-mono text-muted-foreground">input.js</span>
          </div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="flex-1 w-full bg-transparent p-6 font-mono text-sm text-gray-300 resize-none focus:outline-none leading-relaxed"
            spellCheck={false}
          />
        </div>

        {/* Results Pane */}
        <div className="flex-1 bg-background flex flex-col overflow-hidden">
          {data ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 flex flex-col h-full"
            >
              <div className="px-4 py-2 bg-green-500/10 border-b border-green-500/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs font-mono text-green-400">Fix Proposed</span>
                </div>
                <span className="text-xs text-muted-foreground">{data.changes.length} changes applied</span>
              </div>
              
              <div className="flex-1 overflow-auto p-6">
                <CodeBlock code={data.fixedCode} language="javascript" className="h-full border-green-500/20" />
              </div>

              <div className="h-1/3 border-t border-white/10 bg-card p-6 overflow-auto">
                <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-accent" />
                  AI Explanation
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {data.explanation}
                </p>
                
                <div className="space-y-2">
                  {data.changes.map((change, i) => (
                    <div key={i} className="flex items-start gap-3 text-xs font-mono bg-secondary/50 p-2 rounded border border-white/5">
                      <span className={cn(
                        "px-1.5 py-0.5 rounded text-[10px] font-bold uppercase",
                        change.type === 'add' ? 'bg-green-500/20 text-green-400' :
                        change.type === 'remove' ? 'bg-red-500/20 text-red-400' :
                        'bg-yellow-500/20 text-yellow-400'
                      )}>
                        {change.type}
                      </span>
                      <span className="text-muted-foreground">Line {change.line}:</span>
                      <span className="text-gray-300">{change.content}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground/40 bg-secondary/5">
              <div className="text-center">
                <ArrowRight className="w-8 h-8 mx-auto mb-3 opacity-20" />
                <p className="text-sm">Run analysis to see optimized code output</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
