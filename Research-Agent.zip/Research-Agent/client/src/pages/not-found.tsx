import { Link } from "wouter";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <div className="bg-card border border-border rounded-xl shadow-2xl p-8 max-w-md w-full text-center">
        <div className="mx-auto w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mb-6">
          <AlertCircle className="w-8 h-8 text-destructive" />
        </div>
        
        <h1 className="text-2xl font-bold font-display text-foreground mb-2">Page Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The requested resource could not be located in the current route configuration.
        </p>

        <Link href="/">
          <a className="inline-flex items-center justify-center px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors w-full">
            Return to Dashboard
          </a>
        </Link>
      </div>
    </div>
  );
}
