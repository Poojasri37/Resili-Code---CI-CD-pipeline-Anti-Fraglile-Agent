import { useAnalysisHistory } from "@/hooks/use-analysis";
import { format } from "date-fns";
import { 
  History as HistoryIcon, 
  Code2, 
  ScanSearch, 
  FileSearch, 
  Database,
  ArrowRight
} from "lucide-react";

const TYPE_ICONS: Record<string, any> = {
  dom: ScanSearch,
  code: Code2,
  log: FileSearch,
  rag: Database,
};

const TYPE_COLORS: Record<string, string> = {
  dom: "text-blue-400 bg-blue-400/10 border-blue-400/20",
  code: "text-purple-400 bg-purple-400/10 border-purple-400/20",
  log: "text-red-400 bg-red-400/10 border-red-400/20",
  rag: "text-green-400 bg-green-400/10 border-green-400/20",
};

export default function History() {
  const { data: history, isLoading } = useAnalysisHistory();

  if (isLoading) return <div className="p-8 text-muted-foreground">Loading history...</div>;

  return (
    <div className="p-8 max-w-5xl mx-auto min-h-screen">
      <header className="mb-8 flex items-center gap-4">
        <div className="p-3 bg-secondary rounded-xl">
          <HistoryIcon className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Analysis History</h1>
          <p className="text-muted-foreground">Archive of all autonomous reasoning sessions.</p>
        </div>
      </header>

      <div className="space-y-4">
        {history?.map((item) => {
          const Icon = TYPE_ICONS[item.type] || Code2;
          const colorClass = TYPE_COLORS[item.type] || TYPE_COLORS.code;

          return (
            <div 
              key={item.id} 
              className="group bg-card hover:bg-secondary/40 border border-white/5 rounded-xl p-4 flex items-center gap-6 transition-all hover:scale-[1.005] hover:shadow-lg"
            >
              <div className={`p-3 rounded-lg ${colorClass}`}>
                <Icon className="w-6 h-6" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <span className="text-white font-medium capitalize font-display tracking-wide">
                    {item.type} Analysis
                  </span>
                  <span className="text-xs text-muted-foreground font-mono px-2 py-0.5 rounded-full bg-white/5">
                    ID: #{item.id}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground truncate font-mono">
                  {JSON.stringify(item.inputContent).substring(0, 80)}...
                </p>
              </div>

              <div className="text-right">
                <div className="text-xs text-muted-foreground mb-1">
                  {item.createdAt ? format(new Date(item.createdAt), "MMM d, HH:mm") : "Just now"}
                </div>
                {item.isFavorite && (
                  <span className="text-xs text-yellow-500 font-medium">★ Saved</span>
                )}
              </div>
              
              <div className="opacity-0 group-hover:opacity-100 transition-opacity px-2">
                <ArrowRight className="w-5 h-5 text-white/50" />
              </div>
            </div>
          );
        })}

        {history?.length === 0 && (
          <div className="text-center py-20 bg-card/50 rounded-xl border border-dashed border-white/10">
            <p className="text-muted-foreground">No analysis history found.</p>
          </div>
        )}
      </div>
    </div>
  );
}
