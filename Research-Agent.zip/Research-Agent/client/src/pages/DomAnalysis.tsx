import { useState } from "react";
import { useDomAnalysis } from "@/hooks/use-analysis";
import { CodeBlock } from "@/components/ui/CodeBlock";
import { AnalysisOverlay } from "@/components/ui/AnalysisOverlay";
import { Play, CheckCircle2, AlertCircle, SearchCode } from "lucide-react";
import { motion } from "framer-motion";

export default function DomAnalysis() {
  const [oldDom, setOldDom] = useState('<button class="btn-primary">Submit</button>');
  const [newDom, setNewDom] = useState('<div class="btn-primary-wrapper"><button id="submit-btn">Submit</button></div>');
  const { mutate, isPending, data, error } = useDomAnalysis();

  const handleAnalyze = () => {
    mutate({ oldDom, newDom });
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 min-h-screen">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">DOM Analysis & Repair</h1>
        <p className="text-muted-foreground text-lg">
          Detect breaking changes in DOM structures and generate resilient selectors using visual-semantic reasoning.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 relative">
        <AnalysisOverlay isVisible={isPending} message="Scanning DOM Structure..." />
        
        {/* Input Panel */}
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-xl p-4 shadow-sm">
            <label className="block text-sm font-medium text-muted-foreground mb-3 font-mono">Original Snapshot (Old DOM)</label>
            <textarea
              value={oldDom}
              onChange={(e) => setOldDom(e.target.value)}
              className="w-full h-64 bg-secondary/30 rounded-lg p-4 font-mono text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none border border-transparent focus:border-primary/30 transition-all"
              placeholder="Paste old HTML..."
            />
          </div>
          
          <div className="bg-card border border-border rounded-xl p-4 shadow-sm">
            <label className="block text-sm font-medium text-muted-foreground mb-3 font-mono">Current Snapshot (New DOM)</label>
            <textarea
              value={newDom}
              onChange={(e) => setNewDom(e.target.value)}
              className="w-full h-64 bg-secondary/30 rounded-lg p-4 font-mono text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none border border-transparent focus:border-primary/30 transition-all"
              placeholder="Paste new HTML..."
            />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isPending || !oldDom || !newDom}
            className="w-full py-4 bg-primary hover:bg-primary/90 text-primary-foreground font-bold rounded-xl shadow-lg shadow-primary/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none"
          >
            {isPending ? (
              <span className="animate-pulse">Reasoning...</span>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" />
                Run Structural Analysis
              </>
            )}
          </button>
        </div>

        {/* Results Panel */}
        <div className="space-y-6">
          {data ? (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              {/* Confidence Badge */}
              <div className="flex items-center justify-between bg-card border border-white/10 p-6 rounded-xl">
                <div>
                  <h3 className="text-sm text-muted-foreground uppercase tracking-wider font-bold mb-1">Confidence Score</h3>
                  <div className="flex items-end gap-2">
                    <span className="text-4xl font-display font-bold text-white">
                      {Math.round(data.confidence * 100)}%
                    </span>
                    <span className="text-sm text-green-400 mb-1.5 font-medium">High Certainty</span>
                  </div>
                </div>
                <div className="h-16 w-16 rounded-full border-4 border-secondary flex items-center justify-center relative">
                  <div 
                    className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent -rotate-45"
                    style={{ clipPath: `polygon(0 0, 100% 0, 100% ${data.confidence * 100}%, 0 100%)` }} 
                  />
                  <CheckCircle2 className="w-8 h-8 text-primary" />
                </div>
              </div>

              {/* Selector Card */}
              <div className="bg-card border border-white/10 rounded-xl overflow-hidden">
                <div className="bg-secondary/50 px-6 py-3 border-b border-white/5 flex items-center justify-between">
                  <span className="text-sm font-medium text-white">Recommended Selector</span>
                  <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full border border-primary/20">Validated</span>
                </div>
                <div className="p-6">
                  <CodeBlock code={data.selector} language="javascript" className="mb-4" />
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {data.explanation}
                  </p>
                </div>
              </div>

              {/* Reasoning Chain */}
              <div className="bg-card border border-white/10 rounded-xl p-6">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                  Reasoning Chain
                </h3>
                <div className="space-y-4">
                  {data.reasoning.map((step, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-6 h-6 rounded-full bg-secondary text-xs flex items-center justify-center font-mono text-muted-foreground border border-white/5">
                          {idx + 1}
                        </div>
                        {idx !== data.reasoning.length - 1 && (
                          <div className="w-px h-full bg-border my-2" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground pt-0.5">{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="h-full flex items-center justify-center border-2 border-dashed border-white/5 rounded-xl bg-secondary/5 text-muted-foreground/50 text-center p-8">
              <div className="max-w-xs">
                <SearchCode className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Input DOM snapshots to initiate structural repair analysis.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
