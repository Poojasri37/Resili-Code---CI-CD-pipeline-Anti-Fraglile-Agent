import { motion, AnimatePresence } from "framer-motion";

interface AnalysisOverlayProps {
  isVisible: boolean;
  message?: string;
}

export function AnalysisOverlay({ isVisible, message = "Analyzing..." }: AnalysisOverlayProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 z-50 bg-background/50 backdrop-blur-sm flex items-center justify-center rounded-xl overflow-hidden"
        >
          <div className="relative w-full h-full flex flex-col items-center justify-center">
            {/* Scanning Line */}
            <motion.div 
              className="absolute top-0 left-0 right-0 h-1 bg-primary shadow-[0_0_20px_rgba(59,130,246,0.8)] z-20"
              animate={{ top: ["0%", "100%", "0%"] }}
              transition={{ duration: 3, ease: "linear", repeat: Infinity }}
            />
            
            {/* Pulsing Grid Background */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20" />
            
            <div className="bg-card border border-white/10 p-6 rounded-2xl shadow-2xl flex flex-col items-center gap-4 z-30 max-w-sm mx-4">
              <div className="relative w-16 h-16">
                <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-spin" />
                <div className="absolute inset-2 rounded-full border-r-2 border-accent animate-spin-slow" />
              </div>
              <div className="text-center">
                <h3 className="text-lg font-bold font-display text-white">{message}</h3>
                <p className="text-sm text-muted-foreground mt-1">Gemini Pro Reasoning Engine</p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
