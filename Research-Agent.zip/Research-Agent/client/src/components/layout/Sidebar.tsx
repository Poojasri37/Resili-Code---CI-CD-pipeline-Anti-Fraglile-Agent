import { Link, useLocation } from "wouter";
import { 
  ScanSearch, 
  Code2, 
  FileSearch, 
  Database, 
  History, 
  Volume2, 
  VolumeX, 
  LayoutDashboard
} from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

const NAV_ITEMS = [
  { href: "/dom-analysis", label: "DOM Analysis", icon: ScanSearch },
  { href: "/code-editor", label: "Code Editor", icon: Code2 },
  { href: "/log-analysis", label: "Log Analysis", icon: FileSearch },
  { href: "/rag-analysis", label: "RAG Analysis", icon: Database },
  { href: "/history", label: "History", icon: History },
];

export function Sidebar() {
  const [location] = useLocation();
  const [voiceEnabled, setVoiceEnabled] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("voice_enabled") === "true";
    setVoiceEnabled(stored);
  }, []);

  const toggleVoice = () => {
    const newState = !voiceEnabled;
    setVoiceEnabled(newState);
    localStorage.setItem("voice_enabled", String(newState));
    
    if (newState && window.speechSynthesis) {
      const u = new SpeechSynthesisUtterance("Voice feedback enabled.");
      window.speechSynthesis.speak(u);
    } else {
      window.speechSynthesis?.cancel();
    }
  };

  return (
    <div className="w-64 bg-card border-r border-border h-screen flex flex-col shadow-2xl z-20 sticky top-0">
      <div className="p-6 flex items-center gap-3 border-b border-white/5">
        <div className="p-2 bg-primary/20 rounded-lg">
          <LayoutDashboard className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="font-display font-bold text-lg tracking-tight">Resili-Code</h1>
          <p className="text-xs text-muted-foreground font-mono">v1.0.4 Research</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20 font-medium" 
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <Icon className={cn("w-5 h-5", isActive ? "stroke-2" : "stroke-1.5")} />
                <span className="font-sans text-sm">{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="sidebar-active"
                    className="absolute left-0 w-1 h-8 bg-primary rounded-r-full"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5">
        <button
          onClick={toggleVoice}
          className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-secondary/50 hover:bg-secondary text-sm transition-colors"
        >
          <span className="flex items-center gap-2 text-muted-foreground">
            {voiceEnabled ? <Volume2 className="w-4 h-4 text-primary" /> : <VolumeX className="w-4 h-4" />}
            Voice Agent
          </span>
          <div className={cn(
            "w-8 h-4 rounded-full p-0.5 transition-colors",
            voiceEnabled ? "bg-primary" : "bg-muted-foreground/30"
          )}>
            <div className={cn(
              "w-3 h-3 bg-white rounded-full shadow-sm transition-transform",
              voiceEnabled ? "translate-x-4" : "translate-x-0"
            )} />
          </div>
        </button>
      </div>
    </div>
  );
}
