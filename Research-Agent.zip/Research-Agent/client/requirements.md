## Packages
framer-motion | For smooth page transitions and analysis scanning effects
prism-react-renderer | For beautiful syntax highlighting of code blocks
date-fns | For formatting timestamps in history

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
  display: ["Space Grotesk", "sans-serif"],
}
